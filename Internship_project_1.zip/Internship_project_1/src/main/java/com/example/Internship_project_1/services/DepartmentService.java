package com.example.Internship_project_1.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Internship_project_1.entity.DepartmentModel;
import com.example.Internship_project_1.entity.StudentModel;
import com.example.Internship_project_1.repository.DepartmentRepository;

@Service
public class DepartmentService {

	@Autowired
	private DepartmentRepository departmentRepository;
	
	/**
	 * @return list of department
	 */
	public List<DepartmentModel> findAll() {
		return (List<DepartmentModel>) departmentRepository.findAll();
	}
	
	/**
	 * @return find department by id
	 */
	public Optional<DepartmentModel> findById(Integer id) {
		return departmentRepository.findById(id);
	}
	
	/**
	 * @return List of students  by id of department
	 */
	//public  List<StudentModel> getStudentsByDepartment(Integer id) {
	//	return departmentRepository.getStudentsByDepartment(id);
	//}
}
