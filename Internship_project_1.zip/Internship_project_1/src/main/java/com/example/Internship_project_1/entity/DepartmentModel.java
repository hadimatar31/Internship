package com.example.Internship_project_1.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "department")
public class DepartmentModel {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private int Id;
	@Column(name = "name")
	private String Name;
	
	/**
	 * Foreign key one department to many student 
	 */
	@OneToMany(mappedBy = "department")
	private List<StudentModel> students;


	public List<StudentModel> getLtstudent() {
		return students;
	}

	public void setLtstudent(List<StudentModel> students) {
		this.students = students;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}
}
