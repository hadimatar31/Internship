package com.example.Internship_project_1.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Internship_project_1.entity.DepartmentModel;
import com.example.Internship_project_1.entity.StudentModel;
import com.example.Internship_project_1.repository.DepartmentRepository;
import com.example.Internship_project_1.repository.StudentRepository;

@Service
public class StudentService {

	@Autowired
	private StudentRepository stdRepository;
	
	/**
	 * @return list of student
	 */
	public List<StudentModel> findStd() {
		return (List<StudentModel>) stdRepository.findAll();
	}
}
