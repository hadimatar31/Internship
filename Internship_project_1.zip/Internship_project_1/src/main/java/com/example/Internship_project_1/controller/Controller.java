package com.example.Internship_project_1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.example.Internship_project_1.entity.DepartmentModel;
import com.example.Internship_project_1.entity.StudentModel;
import com.example.Internship_project_1.services.DepartmentService;
import com.example.Internship_project_1.services.StudentService;

import java.util.List;
import java.util.Optional;

@RestController
public class Controller {

	@Autowired
	private StudentService studentService;
	
	@Autowired
	private DepartmentService departmentService;

	/**
	 * @return list of student
	 */
    @GetMapping("/findStd")
    public List<StudentModel> findAllStd(){
        return studentService.findStd();
    }
    
	/**
	 * @return list of department
	 */
    @GetMapping("/findAll")
    public List<DepartmentModel> findAll(){
        return departmentService.findAll();
    }
    
	/**
	 * @return find department By id
	 */
    @GetMapping("/department/{id}")
    public Optional<DepartmentModel> findById(@PathVariable("id") Integer id ){
        return departmentService.findById(id);
    }
    
    /**
	 * @return List of Student By id of depatment 
	 */
   // @GetMapping("/department/{id}/student")
   // public List<StudentModel> getStudentByDepartment(@PathVariable("id") Integer id ){
    //    return departmentService.getStudentsByDepartment(id);
    //}
    
}
