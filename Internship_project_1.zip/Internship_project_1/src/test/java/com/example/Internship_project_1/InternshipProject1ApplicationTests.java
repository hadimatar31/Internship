package com.example.Internship_project_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternshipProject1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
